# Smart Expense Tracker

A simple PHP-based web application to manage income, expenses, and balance. The project is deployed on an AWS EC2 instance using Apache, PHP, and MariaDB.

## 📌 Project Overview

**Smart Expense Tracker** helps users record their income and expenses and view their financial summary from a simple dashboard.

### Main Features

- User Registration
- User Login / Logout
- Add Income
- Add Expenses
- Automatic Balance Calculation
- Recent Transactions
- MySQL/MariaDB database integration
- PHP backend
- AWS EC2 deployment

## 🛠️ Technologies Used

- **Frontend:** HTML5, CSS3
- **Backend:** PHP 8.5
- **Database:** MariaDB 10.11
- **Web Server:** Apache HTTP Server
- **Cloud:** AWS EC2
- **Version Control:** Git & GitHub
- **Operating System:** Amazon Linux 2023

## 📂 Project Structure

```text
PHP-Smart_Expense_Tracker/
│
├── assets/
│   └── CSS / other frontend assets
│
├── config/
│   └── db.php
│
├── add_transaction.php
├── dashboard.php
├── database.sql
├── index.php
├── login.php
├── logout.php
├── register.php
├── README.md
└── smart_expense_tracker.zip
```

## 🗄️ Database

Database name:

```text
expense_tracker
```

Main tables:

```text
users
transactions
```

### Users Table

Stores registered user information.

### Transactions Table

Stores income and expense records.

## ☁️ AWS EC2 Deployment

The application was deployed on an AWS EC2 instance running Amazon Linux 2023.

### 1. Update Packages

```bash
sudo yum update -y
```

### 2. Install Apache

```bash
sudo yum install -y httpd
sudo systemctl start httpd
sudo systemctl enable httpd
```

### 3. Install PHP

```bash
sudo yum install -y php php-mysqlnd php-cli php-fpm php-json php-mbstring
```

Check PHP:

```bash
php -v
```

### 4. Install Git

```bash
sudo yum install -y git
```

### 5. Clone Project

```bash
cd /var/www/html
sudo git clone https://github.com/tejasgandhare49/PHP-Smart_Expense_Tracker.git .
```

### 6. Extract Project Files

```bash
sudo unzip smart_expense_tracker.zip
```

### 7. Install MariaDB

```bash
sudo yum install -y mariadb1011-server
sudo systemctl start mariadb
sudo systemctl enable mariadb
```

### 8. Create Database

```bash
sudo mariadb
```

Inside MariaDB:

```sql
CREATE DATABASE expense_tracker;
USE expense_tracker;
SOURCE /var/www/html/database.sql;
SHOW TABLES;
```

Expected tables:

```text
users
transactions
```

### 9. Create Database User

For the application, use a dedicated database user instead of the MariaDB root account.

```sql
CREATE USER 'expense_user'@'localhost' IDENTIFIED BY 'YOUR_DATABASE_PASSWORD';
GRANT ALL PRIVILEGES ON expense_tracker.* TO 'expense_user'@'localhost';
FLUSH PRIVILEGES;
```

> Replace `YOUR_DATABASE_PASSWORD` with your own password. Do not publish the real database password on GitHub.

### 10. Configure Database Connection

File:

```text
config/db.php
```

Example:

```php
<?php
$host = 'localhost';
$db   = 'expense_tracker';
$user = 'expense_user';
$pass = 'YOUR_DATABASE_PASSWORD';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
```

## 🔐 AWS Security Group

The EC2 Security Group should allow:

| Type | Port | Purpose |
|---|---:|---|
| SSH | 22 | Remote server access |
| HTTP | 80 | Website access |

MariaDB port **3306** does not need to be publicly opened because the database is running locally on the same EC2 instance.

## 🌐 Application URL

After deployment, open:

```text
http://<EC2-PUBLIC-IP>/
```

Example:

```text
http://3.91.16.129/
```

> The public IP can change if the EC2 instance is stopped and started unless an Elastic IP is assigned.

## 📸 Screenshots

Add your screenshots inside a `screenshots` folder in the GitHub repository.

Recommended structure:

```text
screenshots/
├── home.png
├── register.png
├── login.png
├── dashboard.png
└── transactions.png
```

### Home Page

![Home Page](./screenshots/home.png)

### Register Page

![Register Page](./screenshots/register.png)

### Login Page

![Login Page](./screenshots/login.png)

### Dashboard

![Dashboard](./screenshots/dashboard.png)

### Transactions

![Transactions](./screenshots/transactions.png)

## 🧪 Testing

The following functions were tested after deployment:

- User registration
- User login
- Database connection
- Adding income
- Adding expense
- Balance calculation
- Recent transactions
- Logout
- PHP and Apache functionality
- MariaDB database and tables

## 🖥️ Useful Database Commands

Enter MariaDB:

```bash
sudo mariadb
```

Select database:

```sql
USE expense_tracker;
```

Show tables:

```sql
SHOW TABLES;
```

View users:

```sql
SELECT * FROM users;
```

View transactions:

```sql
SELECT * FROM transactions;
```

Exit MariaDB:

```sql
EXIT;
```

## 🏗️ Architecture

```text
                    Internet
                       │
                       ▼
                AWS EC2 Instance
                       │
                  Apache Web Server
                       │
                    PHP App
                       │
                       ▼
                    MariaDB
                       │
                expense_tracker
                 ┌─────┴─────┐
                 ▼           ▼
               users    transactions
```

## 🎯 Learning Outcomes

Through this project, I learned:

- PHP web application deployment
- Apache web server configuration
- MariaDB database setup
- PHP-MariaDB connectivity
- Linux commands on AWS EC2
- Git and GitHub
- AWS EC2 deployment
- Basic cloud application architecture
- Database user and privilege management
- Security Group configuration

## 👨‍💻 Author

**Tejas Gandhare**

BSc Computer Science

## 📄 Conclusion

Smart Expense Tracker is a practical PHP web application deployed on AWS EC2 with Apache, PHP, and MariaDB. It demonstrates the complete process of developing, configuring, deploying, and testing a database-driven web application in a cloud environment.
