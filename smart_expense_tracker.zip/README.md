# Smart Expense Tracker

PHP + MySQL expense tracking application prepared for AWS EC2 deployment practice.

## Features
- User registration and login
- Income and expense transactions
- Categories
- Dashboard totals
- Balance calculation
- Recent transaction history
- Responsive UI

## Local setup
1. Install Apache/PHP/MySQL (XAMPP is easiest on Windows).
2. Copy the project into `htdocs`.
3. Create/import the database using `database.sql`.
4. Update `config/db.php` if your MySQL credentials differ.
5. Open `http://localhost/smart_expense_tracker/`.

## AWS EC2
Recommended architecture:
Browser -> EC2 (Apache + PHP) -> RDS MySQL

For production, do not keep database passwords in source code. Use environment variables or AWS Secrets Manager.

## Demo login
Email: demo@example.com
Password: password

Change/remove the demo credentials before using the project publicly.
